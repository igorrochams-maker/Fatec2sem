/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package listaduplamenteencadeada;

/**
 *
 * @author Alunos
 */
public class ListaDuplamenteEncadeada {

    //Atributos
    private NoDuplo primeiroNo;
    private NoDuplo ultimoNo;
    private int qtdNo;
    
    public void adicionar(Object info){
        //Adiciona um novo nó no final da lista
    }
    public void adicionar (Object info, int indice){
        //Adiciona um novo nó na posição definida por índice
    }
    public void remover(int indice){
        //remove o nó correspondente ao índice
    }
    private NoDuplo getNo(int indice){
        //Retorna o nó corresponte ao índice
        return new NoDuplo("a");
    }
    public Object getInfo(int indice){
        //Retorna a informação do nó corresponte ao índice
        return "";
    }
    public void setInfo(int indice, Object info){
        //Altera o valor de info do nó correspondente
    }
    private NoDuplo percorrerLista(int indice){
        /*Percorrer a lista do inicio para o fim,
          até atingir a posição definida por ínidce,
          retornando o Nó correspondente.*/
        return null;
    }
    public int tamanho(){
        return qtdNo;
    }
    public static void main(String[] args) {
        int[] vetor = new int[1000];
        
        for(int i=0; i<vetor.length;i++){
            //Gera 1000 valores randomicos
            vetor[i] = (int) (Math.random() * 1000);
            System.out.println(vetor[i] + " ");
        }
        
        int [] vetorOrdenado = Ordenacao.OrdenacaoTrocaCrescente();
        
        for(int i=0;i<vetorOrdenado.length;i++){            
            System.out.print(vetor[i]+" ");
        }
        
    }
    
}

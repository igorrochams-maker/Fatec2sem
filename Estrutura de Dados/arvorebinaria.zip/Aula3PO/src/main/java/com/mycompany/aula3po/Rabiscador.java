/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.aula3po;

/**
 *
 * @author Alunos
 */
public interface Rabiscador {
    public abstract void tampar();
    public abstract void destampar();
    public abstract void escrever();
    
    
}

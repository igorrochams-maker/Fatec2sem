/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula3po;

/**
 *
 * @author Alunos
 */
public class Aula3PO {

    public static void main(String[] args) {
        
        Caneta c1 = new Caneta();
        c1.setCor("Preto");
        c1.setModelo("");
        c1.setMarca("");
        c1.setCarga(10);
        c1.setTipo("");
        
        
        
    }
}

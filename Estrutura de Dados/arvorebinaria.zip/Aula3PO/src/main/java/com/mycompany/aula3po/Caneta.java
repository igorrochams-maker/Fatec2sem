/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula3po;

/**
 *
 * @author Alunos
 */
public class Caneta implements Rabiscador {
    
    public String cor;
    public String modelo;
    private String marca;
    private String tipo;
    protected int carga;
    private float ponta;
    private boolean tampada;
    
    public void setCor(String c){
        this.cor = c;
        
    }
    
    public String getCor() {
        return this.cor;
    }
    
    public void setModelo(String m) {
        this.modelo = m;
    }
    
    public String getModelo() {
        return this.modelo;
    }
    
    public void setMarca(String m) {
        this.marca = m;
    }
    
    public String getMarca(){
        return this.marca;
    }
    
    public void setTipo(String t){
        this.tipo = t;
    }
    
    public String getTipo(){
        return this.tipo;
    }
    
    public void setCarga(int c){
        this.carga = c;
    }
    
    public int getCarga(){
        return this.carga;
    }
    
    public void setPonta(float p) {
        this.ponta = p;
    }
    
    public float getPonta(){
        return this.ponta;
    }
    
    public void setTampa(boolean t) {
        this.tampada = t;
    }
    
    public boolean getTampa(){
        return this.tampada;
    }
    
    public void status(){
        System.out.println("A cor: " + this.getCor());
        System.out.println("O modelo: " + this.getModelo());
        System.out.println("A marca: " + this.getMarca());
        System.out.println("O tipo: " + this.getTipo());
        System.out.println("A ponta: " + this.getPonta());
        System.out.println("A carga: " + this.getCarga());
        if (this.tampada == true){
        System.out.println("Está tampada! ");
        } else {
            System.out.println("Não está tampada!");
        }
    }
    
    /**
     *
     */
    @Override
    public void escrever() {
        if (this.tampada == false){
            System.out.println("Está escrevendo");
        }
        else {
            System.out.println("ERROR: Caneta tampada!");
        }
    }
    
    @Override
    public void tampar() {
        this.tampada = true;
    }
    
    /**
     *
     */
    @Override
    public void destampar() {
        this.tampada = false;
    }
    
    
}

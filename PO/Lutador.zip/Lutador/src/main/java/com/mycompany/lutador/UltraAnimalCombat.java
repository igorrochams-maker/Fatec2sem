/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lutador;

/**
 *
 * @author Alunos
 */
public class UltraAnimalCombat {
    
    public static void main(String[] args) {
        Lutador l[] = new Lutador[4];
    
        l[0] = new Lutador("Urso", "Selva", 28, 1.75f, 65.9f, 0, 0, 0);
        l[1] = new Lutador("Hipopotamo", "Pantanal", 18, 1.52f, 69.5f, 0, 0, 0);
        l[2] = new Lutador("Tubarão", "Oceano Atlântico", 23, 1.83f, 87.4f, 0, 0, 0);
        l[3] = new Lutador("Leão Marinho", "Oceano Pacífico", 38, 2.10f, 99.4f, 0, 0, 0);

        Luta UAC1 = new Luta();
        
        UAC1.MarcarLuta(l[2],l[3]);
        UAC1.Lutar();
        
        UAC1.MarcarLuta(l[1], l[2]);
        UAC1.Lutar();
    }
}

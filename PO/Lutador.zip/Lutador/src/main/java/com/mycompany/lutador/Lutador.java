/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lutador;

/**
 *
 * @author Alunos
 */
public class Lutador {
    private String nome, nacionalidade, categoria;
    private int idade, vitorias, derrotas, empates;
    private float altura, peso;
    
    public Lutador(String no, String na, int id, float al, float pe, int vi, int de, int em)
    {
        this.nome = no; this.nacionalidade = na; this.idade = id; this.altura = al;
        this.peso = pe; this.vitorias = vi; this.derrotas = de; this.empates = em;
    }
    
    public void SetPeso(float pe){
        this.peso = pe;
        this.SetCategoria();
    }
    
    public void SetCategoria(){
        if (this.peso < 55) { System.out.println("Peso não pertence a nenhuma categoria, VAI TREINAR!"); }
        else if ( this.peso < 70) { this.categoria = "Peso Leve"; }
        else if ( this.peso < 90 ) { this.categoria = "Peso Médio"; }
        else if ( this.peso < 120 ) { this.categoria = "Peso Pesado";}
        else {System.out.println("Peso não pertence a nenhuma categoria, VAI TREINAR!");}
        
    }
    
    public void GanharLuta() { this.vitorias++; }
    public void PerderLuta() { this.derrotas++; }
    public void EmpatarLuta() { this.empates++; }
    
    public String GetNome() { return this.nome; }
    public String GetCategoria() { return this.categoria; }
    public int GetIdade() {return this.idade; }
    public float GetAltura(){ return this.altura; }
    public String GetNacionalidade() { return this.nacionalidade; }
    
    public void SetNome(String no){this.nome = no; }
    public void SetIdade(int id) { this.idade = id; }
    public void SetAltura(float al) {this.altura = al;}
    public void SetNacionalidade(String na){ this.nacionalidade = na; } 
    
    
    
    
    
    public static void main(String[] args) {
        
    }
}

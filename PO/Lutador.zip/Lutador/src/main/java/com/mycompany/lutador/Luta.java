/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lutador;

/**
 *
 * @author Alunos
 */
public class Luta {
    private Lutador desafiado;
    private Lutador desafiante;
    private int rounds;
    private boolean aprovada;
    
    public void MarcarLuta(Lutador l1, Lutador l2) {
        if (l1.GetCategoria().equals(l2.GetCategoria()) && (l1 != l2)) {
            this.aprovada = true;
            this.desafiado = l1;
            this.desafiante = l2;
            
        } else {
            this.aprovada = false;
            this.desafiado = null;
            this.desafiante = null;
        }
    }
    
    public void Lutar(){
        if(this.aprovada) {
            System.out.println("--- DESAFIADO ---");
            this.desafiado.GetNome();
            System.out.println("--- DESAFIANTE ---");
            this.desafiante.GetNome();
            
            int vencedor = (int) (Math.random() * 4);
            switch(vencedor) {
                case 0 : System.out.println(this.desafiado.GetNome() + "");
            }
        }
    }
    
}
